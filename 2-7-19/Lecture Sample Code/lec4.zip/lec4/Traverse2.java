import java.util.LinkedList;
import java.util.Iterator;

class Traverse2{
	public static void main(String[] args){
		LinkedList<Integer> list = new LinkedList<Integer>();
		int SIZE = 100000;
		
		for (int i=0; i<SIZE; i++)
			list.add(i);
			
		Iterator<Integer> iter = list.iterator();
		int sum = 0;
		while (iter.hasNext())
			sum += iter.next();			// Use the iterator with efficient iteration!
		
		System.out.println(sum);

	
	}
}