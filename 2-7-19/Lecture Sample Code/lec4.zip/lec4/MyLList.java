/**
 * our singly-linked list class 
 * generic: can hold any item
 */

import java.util.Iterator;
import java.util.NoSuchElementException;
class MyLList<T> implements Iterable<T>{
	
	/* class for the internal node */
	/* not visible to the outside */
	
	private class Node<T>{
		T value;		// data to store
		Node<T> next;	// link to the next node
		
		public Node(T value){
			this.value = value;
			this.next = null;
		}
	}
	
	
	private Node<T> head;  	// first node
	private Node<T> tail;  	// last node
	private int size=0;		// how many nodes
	
	public Iterator<T> iterator(){
		return new Iterator<T>(){
			
			Node<T> current = head;
			
			public boolean hasNext(){
				if (current!=null)
					return true;
				return false;				
			}
			
			public T next(){			
				if (hasNext()){
					T tmp = current.value;
					current = current.next;
					return tmp;
				}
				else
					throw new NoSuchElementException();
			
			}
		};
	}
	
	// how many nodes are there?
	public int size(){
		return size;
	}
	
	// add a new node to the end of the linked list to hold thing
	public void append(T thing){
		// create a node for thing
		Node<T> node = new Node<>(thing);
		
		// add it to the end of the linked list
		
		if (size==0){
			head = node;
		}
		else{
			tail.next = node;
		}		
		tail = node;
		

		// maintain the size
		size ++;
		
	}
	
	
	
	// return item at location index
	public T get(int index){
		// check index
		
		// not valid, exception / reject
		if (index<0 || index>size-1)
			throw new IndexOutOfBoundsException();
		
		// if valid, iterate to find the location
		Node<T> current = head;
		for (int i =0; i<index;i++){
			current = current.next;
		}
		
		return current.value;

	}
	
	//remove based on index
	public T remove(int index){
	
		//check index
		// not valid: exception/reject
		if (index<0 || index>size-1)
			throw new IndexOutOfBoundsException();
		
		if (index==0){
			//remove from the head: update head reference
			T toReturn = head.value;
			head = head.next;
			
			//decrement size
			size--;
			
			//only node removed
			if(size == 0)
				tail = null;
				
			return toReturn;
		}
		//iterate to find index
		else{
			Node<T> previous = head;
			Node<T> current = head.next;
			for (int i=0;i<index-1;i++){
				previous = previous.next;
				current = previous.next;
			}
		
			// remove node
			previous.next = current.next;
			
			// remove the last node
			if (index==size-1)
				tail = previous;
			
			// decrement size
			size--;
			
			// return value from the removed node
			return current.value;
		}
	
	
	}


	/*
	// return index of an item
	// if not found, return -1
	public int indexOf(T thing){
	
	}
	*/ 

	/*
	// given a thing, remove the first occurrence of that thing
	// return true/false if succeed/fail
	// variations: return the original index
	// 			   remove at a particular index
	public boolean remove(T thing){

	}
	*/
	
	/*	
	// set/replace item at location index
	public void set(int index, T thing){

	}
	*/
	
	
	/* 
	//insert value at index 
	public void insert(int index, T value){
	
	}
	*/
		
	
	// return a string representation
	public String toString(){
		StringBuilder s = new StringBuilder("a MyLList with " + 
											size() + " items:");
		Node<T> current = head;
		int index = 0;
		while (current!=null){
			s.append(" ["+current.value+"]-->");
			current = current.next;
			index ++;
		}
		s.append(" null");

		if (head == null)
			s.append("\nhead-->null\n");
		else
			s.append("\nhead-->["+head.value+"]\n");
			
		if (tail == null)
			s.append("tail-->null\n");
		else
			s.append("tail-->["+tail.value+"]\n");
		
		return s.toString();
		
	}
	

}