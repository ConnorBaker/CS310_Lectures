import java.util.ArrayList;
import java.util.ListIterator;


/* demo the usage of Java ListIterator */

class LIDemo{

	public static void main(String[] args){
		ArrayList<String> fruits = newFruitList();
		ListIterator<String> iter = fruits.listIterator();
		System.out.println(fruits);		

		/*
		System.out.println("----------------------------");
		System.out.println("Have we reached the end? " + !iter.hasNext());
		
		
		System.out.println("iterating forward:");
		while(iter.hasNext()){
			System.out.print("  "+ iter.next());
		}
		//System.out.println(iter.next());		// exception triggered
		System.out.println("");
				
		
		System.out.println("iterating backward:");
		while(iter.hasPrevious()){
			System.out.print("  "+iter.previous());
		}
		System.out.println("");
		*/
		
		
		/*
		// demo add effect
		System.out.println("----------------------------");
		fruits = newFruitList();
		iter = fruits.listIterator();
		System.out.println("next: "+ iter.next());
		System.out.println("next: "+ iter.next());
		iter.add("grape");
		//System.out.println("add(\"grape\"), then next: "+ iter.next());
		//System.out.println("add(\"grape\"), then previous: "+ iter.previous());
		iter.add("banana");
		//fruits.remove(0);
		//System.out.println("next: "+ iter.next()); // not allowed after updating arraylist directly
		System.out.println(fruits);
		*/
		
		
		
		
		// demo remove effect
		System.out.println("----------------------------");
		fruits = newFruitList();
		iter = fruits.listIterator();
		iter.next();
		iter.hasNext();
		iter.remove();	// remove the last next()
		//iter.remove();		//not allowed
		System.out.println("after next, remove: "+fruits);
		
		System.out.println("----------------------------");
		fruits = newFruitList();
		iter = fruits.listIterator();
		iter.next();
		iter.next();
		iter.previous();
		iter.remove();	// remove the last previous()
		//System.out.println(iter.next());
		System.out.println("after next, next, previous, remove: "+fruits);
		
		

	}
	
	public static ArrayList<String> newFruitList(){
		ArrayList<String> fruits = new ArrayList<String>();
		fruits.add("apple");
		fruits.add("orange");
		fruits.add("kiwi");
		fruits.add("mango");
		return fruits;
	}
}