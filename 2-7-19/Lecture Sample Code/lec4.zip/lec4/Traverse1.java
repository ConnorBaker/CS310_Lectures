import java.util.LinkedList;
import java.util.Iterator;

class Traverse1{
	public static void main(String[] args){
		LinkedList<Integer> list = new LinkedList<Integer>();
		int SIZE = 100000;
		
		for (int i=0; i<SIZE; i++)
			list.add(i);
			
		int sum = 0;
		for (int i=0; i<SIZE; i++)
			sum += list.get(i);		// Use the slow get(i) ....
		
		System.out.println(sum);
	
	}
}