/**
 * Our expandable array class
 * generic: can hold any type
 */
 
public class MyArrayList<T>{

	// underlying array
	private T[] data;
	
	// how many items in data array currently
	private int size;
	
	// constructor
	// create an empty array of some default initial capacity
	
	@SuppressWarnings("unchecked")
	public MyArrayList(){
		data = (T[]) new Object[5];  
		size = 0;
	}
	
	// actual length of the array
	public int size(){
		return size;
	}

	public String toString(){
		StringBuilder s = new StringBuilder("one MyArrayList with " + 
											size() + " items:");
		for (int i=0; i<size; i++)
			s.append("\n  ["+i+"]: "+data[i]);
		return s.toString();
		
	}

	
	
	// return the item at index i
	public T get(int i){

		// check index i
		// valid range? [0,size-1]

		// if valid
		return data[i];
		
		// invalid i: reject / exception

	}
	
	
	
	// set/replace item at index i to be x, cannot append	
	public void set(int i, T x){
	
	
	}
	
		
	
	// Add an element to the end 	 		 
	//@SuppressWarnings("unchecked")
	public void add(T x){

		//ensure there is still space
		if (size==data.length){
			T[] newData = (T[]) new Object[size*2];
			
			//copy from old array
			for (int i=0;i<size;i++){
				newData[i] = data[i];
			}
				
			data = newData;
			
		}
		
		//add x
		data[size] = x;
		size++;
	}
	
	
	
	// Remove and return element at position i
	// shift elements to remove the gap
	// Other variations: remove an item x?
	
	public T remove(int i){
		return null;	
	}  
	

	
	
	//Insert x at position i, shift elements if necessary  
	//@SuppressWarnings("unchecked")
	public void insert(int i, T x){
		// check index i
		// valid range? [0,size]
		
		// reject/exception if invalid
		
		// if valid:
		
			// 1. ensure space available (double as needed)
			// 2. shift values if needed
			// 3. place value x at index i	 
	}
	
	
	
	
	// search for x
	// return the index for its first occurence
	// return -1 if not found 
	// other variations: boolean contains()
	
	public int indexOf(T x){
	
		return -1;
	}
	

}

