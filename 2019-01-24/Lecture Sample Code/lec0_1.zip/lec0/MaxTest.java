public class MaxTest{
	public static void main(String [] args){

		/* prepare an array of integers */
		int SIZE = 1000000;
		int [] A = new int[SIZE];
		for (int i=0; i<SIZE;i++){
			A[i] = i;
		}

		/* find the max value in the array */
		int max = findMax(A);
		System.out.println("Max:"+max);
		
	}
	
	/* assume the array parameter A has at least one value */
	public static int findMax(int [] A){
		int ans = A[0];
		
		//check for every item: is this the max value?
		for (int i=1;i<A.length;i++){
			boolean biggest = true;	
			
			//compare this item against all items in the array	
			for (int j=0;j<A.length;j++){
				if (A[i]<A[j]){
					//some other item is bigger: no need to continue
					biggest = false;
					break;
				}
			}
			if (biggest){
				// this is the biggest: return
				return A[i];
			}
		}
		return ans;
	}
}