public class MaxTest2{
	public static void main(String [] args){
		/* prepare an array of integers */
		int SIZE = 1000000;
		int [] A = new int[SIZE];
		
		for (int i=0; i<SIZE;i++){
			A[i] = i;
		}
		
		/* find the max value in the array */
		int max = findMax(A);
		System.out.println("Max:"+max);
		
	}

	/* assume the array parameter A has at least one value */
	public static int findMax(int [] A){
		//max remembers the highest value we've seen so far
		int max = A[0];
		
		for (int i=1;i<A.length;i++){
			if (A[i]>max)
				//update max if needed
				max = A[i];
		}
		return max;
	}
	
	
}