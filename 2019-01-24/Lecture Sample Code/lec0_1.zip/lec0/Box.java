/**
 * generic class example: a Box that can hold anything
 * @author YZ
 */

class Box<T> {
	
	/**
	 *  The thing in the box
	 */	
	// private field that stores a type T item
	private T thing;

	// getter and setter since thing is private
	/**
	 * Returns the contents in the box
	 *  
	 * @return the contents in the box
	 */
	public T get(){
		return thing;
	}

	/**
	 *  Sets the contents of the box
	 *  
	 *  @param thing is the contents to store
	 */
	public void put(T thing){
		this.thing = thing;
	}
	
	/**
	 *  Returns a string representation of the box and its contents.
	 *  
	 *  @return a string representation of the box and its contents
	 */
	@Override
	public String toString(){
		return "Box with "+thing.toString();
	}

	/**
	 * main method that does stuff
	 * @param args not used
	 * @return ....
	 * @throw nothing 
	 */
	public static void main(String[] args) {
	
		// a Box with Integer content
		Box<Integer> ibox = new Box<>();
		
		// Box methods
		ibox.put(100);
		System.out.println(ibox);
		
				
		/**
		 * local class Cat 
		 */
		class Cat{
			String name;
			
			public Cat(String name){
				this.name = name;
			}
			
			public String toString(){
				return "Cat: "+name;
			}
		}
				
		// a Box with Cat content
		Box<Cat> cbox = new Box<>();

		// Box methods
		cbox.put(new Cat("tom"));
		System.out.println("cat box with "+cbox.get());
						
		// declare an array of 10 (general) boxes
		// put our integer-box and cat-box into the array
		
		// version 3 that compiles and only allows actions that are not type-specific
		// e.g. toString or get (sometimes)
		Box<?>[] boxes = new Box<?>[10];
		
		// version 2 that can compiles but with undesirable behavior 
		//Box[] boxes = new Box[10];
		
		
		// version 1 that does not compile: 
		// problem 1: generic array creation
		// problem 2: Box<Integer> not compatible with Box<Object>
		//Box<Object>[] boxes = new Box<Object>[10];


		//operations
		boxes[0] = ibox;
		boxes[1] = cbox;
		
		System.out.println("We have boxes as follows:");
		for (Box<?> box:boxes){
			if (box!=null)
				System.out.println("\t" + box);
		}

		// version 2 w/ warning and unexpected behavior 
		/*for (Box<?> box:boxes){
			if (box!=null)
				box.put(310);
		}

		System.out.println("Now, we have boxes as follows:");
		for (Box<?> box:boxes){
			if (box!=null)
				System.out.println("\t" + box);
		}
		System.out.println("Cbox: "+cbox);*/
		// end version 2 testing
		
		//declare an array of 10 integer boxes
		Box<Integer> iboxes[] = new Box[10];
		for (int i=0;i<iboxes.length;i++){
			iboxes[i] = new Box<Integer>();
			iboxes[i].put(i);
		}

		for (int i=0;i<iboxes.length;i++){
			System.out.println(iboxes[i]);
		}

	}
}

