class LLRecursionDemo{

	static class Node<T>{
		T data;
		Node<T> next;
		
		public Node(T data){
			this.data = data;
		}
		
	}
	
	
	public static void main(String[] args){
		Node<Integer> node1 = new Node<>(20);
		Node<Integer> node2 = new Node<>(10);
		Node<Integer> node3 = new Node<>(30);
		node1.next = node2;
		node2.next = node3;
		
		System.out.println(method1(node1));
		System.out.println(method2(node1));

	}
	
	
	public static<T> int method1(Node<T> node){
		if (node == null)
			return 0;
		else
			return 1+method1(node.next);
	}


	public static int method2(Node<Integer> node){
		if (node == null)
			return 0;
		else
			return node.data+method2(node.next);
	}

}