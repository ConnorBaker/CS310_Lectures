// Demonstration of iterative recursive versions of list length
// functions

// Singly linked
// No header/auxiliary/dummy nodes
public class SimpleList<T>{
  static class Node<T> {
    T data; Node<T> next;
    public Node(T d, Node<T> n){
      this.data=d; this.next=n;
    }
  }

  Node<T> head;  // null When empty
  public SimpleList(T a[]){
    if(a.length==0){ return; }
    this.head = new Node<T>(a[0],null);
    Node<T> iter = this.head;
    for(int i=1; i<a.length; i++){
      iter.next = new Node<T>(a[i],null);
      iter = iter.next;
    }
  }

  // Iterative version
  public int lengthIter(){
    return lengthIter(this.head);
  }

  // Recursiver version
  public int length(){
    return length(this.head);
  }

  // Iterative version
  public static <T> int lengthIter(Node<T> n){
    Node<T> iter = n;
    int len = 0;
    while(iter != null){
      len++;
      iter = iter.next;
    }
    return len;
  }
  // Recursive version
  public static <T> int length(Node<T> n){
    if(n==null){
      return 0;
    }
    else{
      return 1 + length(n.next);
    }
  }

  // Demonstatrate Lengths
  public static void main(String args[]){
    SimpleList<String> l7 = 
      new SimpleList<String>(new String[]{"A","B","C","D","E","F","G"});
    System.out.println(l7.length());
    System.out.println(l7.lengthIter());

    SimpleList<Integer> l4 = 
      new SimpleList<Integer>(new Integer[]{1,2,3,4});
    System.out.println(l4.length());
    System.out.println(l4.lengthIter());

    SimpleList<Integer> l0 = 
      new SimpleList<Integer>(new Integer[]{});
    System.out.println(l0.length());
    System.out.println(l0.lengthIter());
  }    

}
