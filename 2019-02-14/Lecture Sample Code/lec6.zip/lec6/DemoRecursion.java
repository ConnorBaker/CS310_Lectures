class DemoRecursion{
	public static void main(String[] args){
		System.out.println(fact(1));
		System.out.println(fact(4));
		
	}
	
	public static int fact(int n){
		//base case
		if (n<=1)
			return 1;
		
		//recursive case
		else
			return n*fact(n-1); //call fact() with a reduced integer
	}
}