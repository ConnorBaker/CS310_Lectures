// Demonstrate recursive implementations of size() and height() for
// trees as well as recursive traversals (preOrder, postOrder, inOrder)
public class Tree<T>{
  public static class Node<T>{ 
    T data; Node<T> left, right; int depth;
    public Node(T d, Node<T> l, Node<T> r){
      this.data=d; this.left=l; this.right=r;
      this.depth=0;
    }
    public String toString(){
    	return "Data: "+this.data+" Depth: "+this.depth;
    }
  }

  Node<T> root;

  public Tree(Node<T> n){
    this.root = n;
  }

  public int size(){
    return size(this.root);
  }

  public void markDepth(){
    markDepth(this.root, 0);
  }

  // Total number of nodes
  public static <T> int size( Node<T> t ){
    if(t == null){
      return 0;
    }
    int sL = size(t.left);
    int sR = size(t.right);
    return 1 + sL + sR;
  }


  public int height(){
    return height(this.root);
  }

  // Depth of deepest node
  public static <T> int height( Node<T> t ){
    if(t == null){
      return -1;
    }
    int hL = height(t.left);
    int hR = height(t.right);
    int deeper = Math.max(hL,hR);
    return 1+deeper;
  }

  // mark depth of each node
  public static <T> void markDepth( Node<T> t, int depth){
    if(t == null){
      return;
    }
    t.depth = depth;
    markDepth(t.left, depth+1);
    markDepth(t.right, depth+1);
    
  }


  public void printPreOrder(){
    preOrder(this.root);
    System.out.println();
  }
  public void printInOrder(){ 
    inOrder(this.root);
    System.out.println();
  }    
  public void printPostOrder(){ 
    postOrder(this.root);
    System.out.println();
  }

  private void inOrder(Node t){
    if(t != null){
      inOrder(t.left);
      //System.out.print(t.data+"-");
      System.out.println(t);
      inOrder(t.right);
    }
  }

  private void preOrder(Node t){
    if(t != null){
      //System.out.print(t.data+"-");
      System.out.println(t);
      preOrder(t.left);
      preOrder(t.right);
    }
  }

  private void postOrder(Node t){
    if(t != null){
      postOrder(t.left);
      postOrder(t.right);
      //System.out.print(t.data+"-");
      System.out.println(t);

    }
  }
                               
  //     1   
  //    / \__
  //   2     4 
  //  /     / \
  // 3     5   7
  //      /   / \
  //     6   8   10
  //        /
  //       9
  @SuppressWarnings("unchecked")
  public static void main(String args[]){
    // Make a tree, the hard way
    Node r = new Node(1,
                      new Node(2,
                               new Node(3,null,null),
                               null),
                      new Node(4,
                               new Node(5,
                                        null,
                                        new Node(6,null,null)),
                               new Node(7,
                                        new Node(8,
                                                 new Node(9,null,null),
                                                 null),
                                        new Node(10,null,null))));
    Tree t = new Tree(r);
    // Demonstrate size and height computations
    System.out.println("Size:   "+t.size());
    System.out.println("Height: "+t.height());
    System.out.println("PreOrder:");
    t.printPreOrder();
    System.out.println("InOrder:");
    t.printInOrder();
    System.out.println("PostOrder: ");
    t.printPostOrder();
    
    t.markDepth();
    System.out.println("\nPreOrder after depth marked:");
    t.printPreOrder();
    
  }
                               

}
