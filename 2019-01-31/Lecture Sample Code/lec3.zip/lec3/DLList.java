/* Example: doubly-linked list */

class DLList<T>{

	private class Node<T>{
		T value; //data storage
		Node<T> prev, next;	// two links
		
		// constructor
		public Node(T value){
			this.value = value;
			prev = next = null; //kind of default
		}

		// constructor that sets the two links
		public Node(T value, Node<T> p, Node<T> n){
			this.value = value;
			this.prev = p;
			this.next = n;
		}
		
	}
	
	private Node<T> headNode, tailNode; // always present, contains no data
	private int size;	// number of data items
	
	public DLList(){
		//initial setting 
		// headNode<->tailNode
		headNode = new Node<>(null,null,null);
		tailNode = new Node<>(null,headNode,null);
		headNode.next = tailNode;
		size = 0;
	}
	
	// add a new item to the end
	public void append(T thing){
		// create a new node
		// add before the dummy tail node 
		
		// headNode<->...<->newNode(T)<->tailNode
		Node<T> node = new Node<>(thing,tailNode.prev,tailNode);
		tailNode.prev.next = node;
		tailNode.prev = node;

		//alternative version
		//node.prev.next = node;
		//node.next.prev = node;

		size++;
	}
	
	// print from head to tail
	public void printList(){
		System.out.println("DLList with "+size+" elements");
		Node<T> current = headNode;
		for (int i=0; i<size+1; i++){
			System.out.print("["+current.value+"]-->");
			current = current.next;
		}
		System.out.println("["+current.value+"]");
			
	}
	
	// print from tail to head	
	public void printReverseList(){
		System.out.println("DLList with "+size+" elements");
		System.out.println("Reverse order:");
		Node<T> current = tailNode;
		for (int i=0; i<size+1; i++){
			System.out.print("["+current.value+"]-->");
			current = current.prev;
		}
		System.out.println("["+current.value+"]");
	
	}
	
	public static void main(String[] args){
		DLList<String> myList = new DLList<String>();
		myList.printList();
		
		myList.append("Richmond");
		myList.append("Norfolk");
		myList.append("Virginia Beach");
		myList.append("Hampton");
		System.out.println("---------------");
		System.out.println("After appending:");
		myList.printList();
		System.out.println("---------------");
		myList.printReverseList();
		
	}


}